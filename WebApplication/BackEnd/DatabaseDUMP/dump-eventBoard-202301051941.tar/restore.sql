--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "eventBoard";
--
-- Name: eventBoard; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "eventBoard" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "eventBoard" OWNER TO postgres;

\connect "eventBoard"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint NOT NULL,
    date date NOT NULL,
    message character varying NOT NULL,
    person bigint NOT NULL,
    event bigint NOT NULL
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: comment_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comment_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_id OWNER TO postgres;

--
-- Name: event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event (
    id bigint NOT NULL,
    "position" bigint NOT NULL,
    date date NOT NULL,
    event_type bigint NOT NULL,
    price real,
    poster character varying NOT NULL,
    soldout boolean,
    description character varying NOT NULL,
    publisher bigint NOT NULL
);


ALTER TABLE public.event OWNER TO postgres;

--
-- Name: event_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_id OWNER TO postgres;

--
-- Name: event_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_type (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description character varying
);


ALTER TABLE public.event_type OWNER TO postgres;

--
-- Name: event_type_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_type_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_type_id OWNER TO postgres;

--
-- Name: mipiace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mipiace (
    person bigint NOT NULL,
    event bigint NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.mipiace OWNER TO postgres;

--
-- Name: partecipation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partecipation (
    person bigint NOT NULL,
    event bigint NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.partecipation OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person (
    id bigint NOT NULL,
    name character varying NOT NULL,
    lastname character varying NOT NULL,
    username character varying NOT NULL,
    email character varying NOT NULL,
    active_status boolean NOT NULL,
    "position" bigint,
    role character varying NOT NULL,
    password character varying NOT NULL
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: person_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.person_id OWNER TO postgres;

--
-- Name: position; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."position" (
    id bigint NOT NULL
);


ALTER TABLE public."position" OWNER TO postgres;

--
-- Name: position_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.position_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.position_id OWNER TO postgres;

--
-- Name: preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preferences (
    person bigint NOT NULL,
    event_type bigint NOT NULL
);


ALTER TABLE public.preferences OWNER TO postgres;

--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    id bigint NOT NULL,
    type bigint NOT NULL,
    status boolean NOT NULL,
    message character varying NOT NULL,
    date date NOT NULL,
    person bigint NOT NULL
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: report_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_id OWNER TO postgres;

--
-- Name: report_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_type (
    column1 bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.report_type OWNER TO postgres;

--
-- Name: report_type_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_type_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_type_id OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    person bigint NOT NULL,
    event bigint NOT NULL,
    date date NOT NULL,
    message character varying NOT NULL,
    rating integer NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: role_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id OWNER TO postgres;

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3400.dat

--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3401.dat

--
-- Data for Name: event_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3402.dat

--
-- Data for Name: mipiace; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3403.dat

--
-- Data for Name: partecipation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3404.dat

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3405.dat

--
-- Data for Name: position; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3406.dat

--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3410.dat

--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3407.dat

--
-- Data for Name: report_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3408.dat

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3409.dat

--
-- Name: comment_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comment_id', 1, false);


--
-- Name: event_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_id', 4, true);


--
-- Name: event_type_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_type_id', 3, true);


--
-- Name: person_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.person_id', 26, true);


--
-- Name: position_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.position_id', 4, true);


--
-- Name: report_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_id', 1, false);


--
-- Name: report_type_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_type_id', 1, false);


--
-- Name: role_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id', 2, true);


--
-- Name: comment comment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pk PRIMARY KEY (id);


--
-- Name: event event_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_pk PRIMARY KEY (id);


--
-- Name: event_type event_type_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_type
    ADD CONSTRAINT event_type_pk PRIMARY KEY (id);


--
-- Name: mipiace like_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT like_pk PRIMARY KEY (person, event);


--
-- Name: partecipation partecipation_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partecipation
    ADD CONSTRAINT partecipation_pk PRIMARY KEY (person, event);


--
-- Name: person person_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pk PRIMARY KEY (id);


--
-- Name: person person_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_un UNIQUE (username);


--
-- Name: person person_unbis; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_unbis UNIQUE (email);


--
-- Name: position position_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."position"
    ADD CONSTRAINT position_pk PRIMARY KEY (id);


--
-- Name: preferences preferences_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_pk PRIMARY KEY (person, event_type);


--
-- Name: report report_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pk PRIMARY KEY (id);


--
-- Name: report_type report_type_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_type
    ADD CONSTRAINT report_type_pk PRIMARY KEY (column1);


--
-- Name: review review_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pk PRIMARY KEY (person, event);


--
-- Name: comment comment_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: comment comment_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_fk2 FOREIGN KEY (event) REFERENCES public.event(id);


--
-- Name: event event_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_fk FOREIGN KEY ("position") REFERENCES public."position"(id);


--
-- Name: event event_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_fk_1 FOREIGN KEY (event_type) REFERENCES public.event_type(id);


--
-- Name: event event_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_fk_2 FOREIGN KEY (publisher) REFERENCES public.person(id);


--
-- Name: mipiace like_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT like_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: mipiace like_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT like_fk_1 FOREIGN KEY (event) REFERENCES public.event(id);


--
-- Name: partecipation partecipation_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partecipation
    ADD CONSTRAINT partecipation_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: partecipation partecipation_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partecipation
    ADD CONSTRAINT partecipation_fk_1 FOREIGN KEY (event) REFERENCES public.event(id);


--
-- Name: person person_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_fk_1 FOREIGN KEY ("position") REFERENCES public."position"(id);


--
-- Name: preferences preferences_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: preferences preferences_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_fk_1 FOREIGN KEY (event_type) REFERENCES public.event_type(id);


--
-- Name: report report_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: report report_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_fk_1 FOREIGN KEY (type) REFERENCES public.report_type(column1);


--
-- Name: review review_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk FOREIGN KEY (person) REFERENCES public.person(id);


--
-- Name: review review_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_1 FOREIGN KEY (event) REFERENCES public.event(id);


--
-- PostgreSQL database dump complete
--

